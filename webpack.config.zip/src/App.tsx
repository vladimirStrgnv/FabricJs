import { fabric } from "fabric";
import { useState, useEffect } from "react";

const App = () => {
  const [canvas, setCanvas] = useState<any>("");
  const [imgURL, setImgURL] = useState('');


  const initCanvas = () => {
  const canvas = new fabric.Canvas("canvas", {
    height: 800,
    width: 800,
    backgroundColor: "pink",
   });

   canvas.on('mouse:wheel', function(opt) {
    var delta = opt.e.deltaY;
    var zoom = canvas.getZoom();
    zoom *= 0.999 ** delta;
    if (zoom > 20) zoom = 20;
    if (zoom < 0.01) zoom = 0.01;
    canvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
    opt.e.preventDefault();
    opt.e.stopPropagation();
    console.log(canvas._objects.length)
  });

  return canvas;
  }

  const addText = canvi => {
    const textEditable = new fabric.Textbox(
      'Editable Textbox', {
      width: 500,
      editable: true
  });
    canvi.add(textEditable);
    canvi.renderAll();
 }


  const addRect = canvi => {
    const rect = new fabric.Rect({
       height: 200,
       width: 200,
       fill: 'yellow'
    });
    console.log(canvas.toSVG())

    canvi.add(rect);
    canvi.renderAll();
 }

  const addImg = (e, url, canvi) => {
    e.preventDefault();
    new fabric.Image.fromURL(url, img => {
      img.scale(0.75);
      canvi.add(img);
      canvi.renderAll();
      setImgURL('');  
    });
 }

 const exportSvg = () => {
 }

  useEffect(() => {
    setCanvas(initCanvas());
  }, []);

  return (
    <div>
      <form onSubmit={(e) => addImg(e, imgURL, canvas)}>
        <div>
          <input
            type="text"
            value={imgURL}
            onChange={(e) => setImgURL(e.target.value)}
          />
          <button type="submit">Add Image</button>
        </div>
      </form>
      <button onClick={() => addRect(canvas)}>Rectangle</button>
      <button onClick={() => addText(canvas)}>Add text</button>
      <button onClick={() => addText(canvas)}>Export svg</button>


      <canvas id="canvas" />
    </div>
  );
};

export default App;
